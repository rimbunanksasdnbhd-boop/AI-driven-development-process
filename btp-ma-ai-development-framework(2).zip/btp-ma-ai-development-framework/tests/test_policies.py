from pathlib import Path

from btp_ma_framework.policies import load_intake_policies
from btp_ma_framework.templates import request_template


def test_policy_defines_expected_workflows() -> None:
    policies = load_intake_policies(Path("config/intake-policy.yaml"))

    assert set(policies) == {
        "requirement-analysis",
        "solution-design",
        "test-script-creation",
        "coding",
    }


def test_generated_template_contains_every_required_input() -> None:
    policy = load_intake_policies(Path("config/intake-policy.yaml"))["coding"]

    generated = request_template(policy)

    assert set(generated["inputs"]) == {item.key for item in policy.required_inputs}
