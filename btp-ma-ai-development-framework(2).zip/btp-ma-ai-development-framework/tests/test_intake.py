from pathlib import Path

import yaml

from btp_ma_framework.intake import validate_intake
from btp_ma_framework.models import DecisionStatus
from btp_ma_framework.policies import load_intake_policies
from btp_ma_framework.prompting import render_missing_input_prompt

POLICY_PATH = Path("config/intake-policy.yaml")


def load_request(path: str) -> dict:
    with Path(path).open(encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def test_requirement_analysis_blocks_without_product_documentation() -> None:
    policies = load_intake_policies(POLICY_PATH)
    request = load_request("requests/examples/requirement-analysis-missing-docs.yaml")

    result = validate_intake(policies["requirement-analysis"], request)

    assert result.status is DecisionStatus.BLOCKED
    assert {issue.key for issue in result.issues} == {
        "product_documentation",
        "existing_requirement_examples",
    }
    prompt = render_missing_input_prompt(result)
    assert "Product documentation" in prompt
    assert "Existing story or requirement examples" in prompt


def test_test_creation_blocks_without_template() -> None:
    policies = load_intake_policies(POLICY_PATH)
    request = load_request("requests/examples/test-script-missing-template.yaml")

    result = validate_intake(policies["test-script-creation"], request)

    assert result.status is DecisionStatus.BLOCKED
    assert [issue.key for issue in result.issues] == ["test_script_template"]
    assert "Test-script template" in render_missing_input_prompt(result)


def test_coding_ready_when_all_mandatory_inputs_are_present() -> None:
    policies = load_intake_policies(POLICY_PATH)
    request = load_request("requests/examples/coding-ready.yaml")

    result = validate_intake(policies["coding"], request)

    assert result.status is DecisionStatus.READY
    assert result.agent == "development-agent"
    assert result.skill == "implementing-approved-changes"
    assert result.issues == []


def test_allowed_waiver_requires_complete_approval_record() -> None:
    policies = load_intake_policies(POLICY_PATH)
    request = load_request("requests/examples/requirement-analysis-missing-docs.yaml")
    request["inputs"]["product_documentation"]["waiver"] = {
        "reason": "Legacy behavior has no maintained documentation.",
        "approved_by": "product-owner@example.invalid",
        "approved_at": "2026-07-21T09:00:00Z",
    }
    request["inputs"]["existing_requirement_examples"]["waiver"] = {
        "reason": "This is the first story for the product.",
        "approved_by": "product-owner@example.invalid",
        "approved_at": "2026-07-21T09:00:00Z",
    }

    result = validate_intake(policies["requirement-analysis"], request)

    assert result.status is DecisionStatus.READY
    assert set(result.accepted_waivers) == {
        "product_documentation",
        "existing_requirement_examples",
    }


def test_non_waivable_codebase_remains_blocking() -> None:
    policies = load_intake_policies(POLICY_PATH)
    request = load_request("requests/examples/coding-ready.yaml")
    request["inputs"]["source_repository"] = {
        "references": [],
        "waiver": {
            "reason": "Repository not supplied.",
            "approved_by": "development-lead@example.invalid",
            "approved_at": "2026-07-21T09:00:00Z",
        },
    }

    result = validate_intake(policies["coding"], request)

    assert result.status is DecisionStatus.BLOCKED
    assert [issue.key for issue in result.issues] == ["source_repository"]
