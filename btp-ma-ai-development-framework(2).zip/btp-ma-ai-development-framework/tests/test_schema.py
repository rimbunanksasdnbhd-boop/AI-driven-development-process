import json
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator


def test_ready_request_matches_schema() -> None:
    schema = json.loads(Path("schemas/request.schema.json").read_text(encoding="utf-8"))
    request = yaml.safe_load(
        Path("requests/examples/coding-ready.yaml").read_text(encoding="utf-8")
    )

    errors = sorted(Draft202012Validator(schema).iter_errors(request), key=lambda error: error.path)

    assert errors == []
