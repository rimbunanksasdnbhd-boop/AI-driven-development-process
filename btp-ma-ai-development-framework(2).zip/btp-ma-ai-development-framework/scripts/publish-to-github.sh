#!/usr/bin/env bash
set -euo pipefail

REPO_URL="${1:-https://github.com/rimbunanksasdnbhd-boop/AI-driven-development-process.git}"
BRANCH="${2:-main}"
COMMIT_MESSAGE="${3:-feat: add BTP@MA AI-driven development framework}"
SOURCE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEMP_ROOT="$(mktemp -d -t btp-ma-publish-XXXXXX)"

cleanup() {
  rm -rf "$TEMP_ROOT"
}
trap cleanup EXIT

command -v git >/dev/null 2>&1 || {
  echo "Git is not installed or is not available in PATH." >&2
  exit 1
}

echo "Checking access to $REPO_URL ..."
git ls-remote "$REPO_URL" >/dev/null

echo "Cloning repository into a temporary workspace ..."
git clone "$REPO_URL" "$TEMP_ROOT"
cd "$TEMP_ROOT"

if git show-ref --verify --quiet "refs/remotes/origin/$BRANCH"; then
  git checkout "$BRANCH"
else
  git checkout -b "$BRANCH"
fi

echo "Copying the framework package ..."
find "$TEMP_ROOT" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +

tar \
  --exclude=.git \
  --exclude=.venv \
  --exclude=__pycache__ \
  --exclude=.pytest_cache \
  --exclude=.ruff_cache \
  --exclude=dist \
  --exclude=build \
  -C "$SOURCE_ROOT" -cf - . | tar -C "$TEMP_ROOT" -xf -

if [[ -z "$(git status --short)" ]]; then
  echo "No changes detected. The repository already contains this package."
  exit 0
fi

echo
echo "Changes to publish:"
git status --short

echo
read -r -p "Push these changes to '$BRANCH'? Type YES to continue: " answer
if [[ "$answer" != "YES" ]]; then
  echo "Publishing cancelled. No remote changes were made." >&2
  exit 1
fi

git add -A
git commit -m "$COMMIT_MESSAGE"
git push -u origin "$BRANCH"

echo
echo "Published successfully: $REPO_URL"
