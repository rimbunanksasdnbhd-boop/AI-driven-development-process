[CmdletBinding()]
param(
    [string]$RepoUrl = "https://github.com/rimbunanksasdnbhd-boop/AI-driven-development-process.git",
    [string]$Branch = "main",
    [string]$CommitMessage = "feat: add BTP@MA AI-driven development framework",
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$SourceRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("btp-ma-publish-" + [guid]::NewGuid().ToString("N"))
$ExcludedNames = @(".git", ".venv", "__pycache__", ".pytest_cache", ".ruff_cache", "dist", "build")

function Invoke-Git {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$GitArgs)
    & git @GitArgs
    if ($LASTEXITCODE -ne 0) {
        throw "Git command failed: git $($GitArgs -join ' ')"
    }
}

try {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        throw "Git is not installed or is not available in PATH."
    }

    Write-Host "Checking access to $RepoUrl ..."
    Invoke-Git ls-remote $RepoUrl | Out-Null

    Write-Host "Cloning repository into a temporary workspace ..."
    Invoke-Git clone $RepoUrl $TempRoot
    Set-Location $TempRoot

    $RemoteBranches = (& git branch -r 2>$null) -join "`n"
    if ($RemoteBranches -match "origin/$([regex]::Escape($Branch))") {
        Invoke-Git checkout $Branch
    }
    else {
        Invoke-Git checkout -b $Branch
    }

    Write-Host "Copying the framework package ..."
    Get-ChildItem -LiteralPath $SourceRoot -Force | Where-Object {
        $ExcludedNames -notcontains $_.Name
    } | ForEach-Object {
        $Destination = Join-Path $TempRoot $_.Name
        if (Test-Path -LiteralPath $Destination) {
            Remove-Item -LiteralPath $Destination -Recurse -Force
        }
        Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse -Force
    }

    $Changes = (& git status --short) -join "`n"
    if ([string]::IsNullOrWhiteSpace($Changes)) {
        Write-Host "No changes detected. The repository already contains this package."
        exit 0
    }

    Write-Host "`nChanges to publish:"
    Write-Host $Changes

    if (-not $Force) {
        $Answer = Read-Host "Push these changes to '$Branch'? Type YES to continue"
        if ($Answer -ne "YES") {
            throw "Publishing cancelled. No remote changes were made."
        }
    }

    Invoke-Git add -A
    Invoke-Git commit -m $CommitMessage
    Invoke-Git push -u origin $Branch

    Write-Host "`nPublished successfully: $RepoUrl"
}
finally {
    Set-Location $SourceRoot
    if (Test-Path -LiteralPath $TempRoot) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
