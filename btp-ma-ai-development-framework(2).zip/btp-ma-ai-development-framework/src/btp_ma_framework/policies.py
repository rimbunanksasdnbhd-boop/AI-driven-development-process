from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import InputRequirement, WorkflowPolicy


class PolicyError(ValueError):
    """Raised when policy configuration is invalid."""


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise PolicyError(f"Policy file does not exist: {path}")
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise PolicyError(f"Policy root must be an object: {path}")
    return data


def load_intake_policies(path: str | Path) -> dict[str, WorkflowPolicy]:
    policy_path = Path(path)
    data = _load_yaml(policy_path)
    workflows = data.get("workflows")
    if not isinstance(workflows, dict) or not workflows:
        raise PolicyError("intake policy must define a non-empty 'workflows' object")

    parsed: dict[str, WorkflowPolicy] = {}
    for workflow_name, raw_workflow in workflows.items():
        if not isinstance(raw_workflow, dict):
            raise PolicyError(f"workflow '{workflow_name}' must be an object")
        raw_inputs = raw_workflow.get("required_inputs", [])
        requirements: list[InputRequirement] = []
        for raw_input in raw_inputs:
            waiver = raw_input.get("waiver", {}) or {}
            accepted = tuple(raw_input.get("accepted_references", []))
            if not accepted:
                raise PolicyError(
                    f"workflow '{workflow_name}' input '{raw_input.get('key')}' "
                    "must define accepted_references"
                )
            requirements.append(
                InputRequirement(
                    key=str(raw_input["key"]),
                    label=str(raw_input["label"]),
                    why=str(raw_input["why"]),
                    accepted_references=accepted,
                    minimum_references=int(raw_input.get("minimum_references", 1)),
                    waiver_allowed=bool(waiver.get("allowed", False)),
                    waiver_approval_role=waiver.get("approval_role"),
                )
            )
        parsed[workflow_name] = WorkflowPolicy(
            name=workflow_name,
            agent=str(raw_workflow["agent"]),
            skill=str(raw_workflow["skill"]),
            required_inputs=tuple(requirements),
        )
    return parsed
