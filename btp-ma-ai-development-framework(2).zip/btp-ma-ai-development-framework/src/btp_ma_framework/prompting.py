from __future__ import annotations

from .models import ValidationResult

WORKFLOW_LABELS = {
    "requirement-analysis": "requirement analysis",
    "solution-design": "solution design",
    "test-script-creation": "test-script creation",
    "coding": "coding",
}


def render_missing_input_prompt(result: ValidationResult) -> str:
    if result.ready:
        return (
            f"The intake gate is ready. Route this work to `{result.agent}` and invoke "
            f"`{result.skill}`."
        )

    workflow_label = WORKFLOW_LABELS.get(result.workflow, result.workflow)
    lines = [
        f"Before I start {workflow_label}, please provide the following source material:",
        "",
    ]
    for index, issue in enumerate(result.issues, start=1):
        accepted = ", ".join(issue.accepted_references)
        lines.append(f"{index}. **{issue.label}** — {issue.reason}")
        lines.append(f"   Accepted references: {accepted}.")
        if issue.waiver_allowed:
            lines.append(
                "   When unavailable, provide a documented reason and approval from "
                f"`{issue.waiver_approval_role}`."
            )
    lines.extend(
        [
            "",
            "You may provide links, uploaded files, repository paths, Jira references, or "
            "a ZIP of the existing codebase. I will inspect everything already supplied and "
            "will not ask for the same material again.",
        ]
    )
    return "\n".join(lines)
