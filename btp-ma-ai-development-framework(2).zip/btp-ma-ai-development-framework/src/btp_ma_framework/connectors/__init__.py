"""Connector interfaces for enterprise systems.

Implementations must obtain credentials from approved secret/destination services and
must enforce the policies in config/tool-policy.yaml.
"""
