# Connector implementation rules

Implement separate adapters for Jira, product documentation, GitHub, SAP BTP, CI/CD, and transport management.

Every adapter must:

1. use an approved technical identity or delegated user identity;
2. retrieve secrets from an enterprise secret/destination service;
3. validate resource scope against `config/tool-policy.yaml`;
4. return source references and audit metadata;
5. separate read, draft-write, approved-write, and destructive operations;
6. implement idempotency for create/update actions;
7. never expose tokens to an LLM prompt or commit them to Git;
8. require human approval for production deployment, merge, deletion, and Jira publication.
