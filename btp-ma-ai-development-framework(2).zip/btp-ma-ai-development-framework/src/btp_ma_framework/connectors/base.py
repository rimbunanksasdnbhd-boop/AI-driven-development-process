from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ConnectorResult:
    reference: str
    payload: dict[str, Any]
    audit_metadata: dict[str, Any]


class ReadConnector(Protocol):
    def read(self, reference: str) -> ConnectorResult:
        """Read an allowlisted resource and return audit metadata."""


class SearchConnector(Protocol):
    def search(self, query: str) -> list[ConnectorResult]:
        """Search an allowlisted source and return traceable results."""


class DraftWriteConnector(Protocol):
    def create_draft(self, payload: dict[str, Any]) -> ConnectorResult:
        """Create a reviewable draft; must not publish without an approval gate."""
