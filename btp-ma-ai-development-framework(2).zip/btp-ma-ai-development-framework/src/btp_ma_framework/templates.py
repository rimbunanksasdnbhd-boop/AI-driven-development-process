from __future__ import annotations

from typing import Any

from .models import WorkflowPolicy


def request_template(policy: WorkflowPolicy) -> dict[str, Any]:
    return {
        "request_id": "REPLACE-ME",
        "workflow": policy.name,
        "title": "Describe the requested change",
        "risk": "medium",
        "inputs": {
            requirement.key: {
                "references": [
                    {
                        "type": requirement.accepted_references[0],
                        "value": "REPLACE-ME",
                        "description": requirement.label,
                    }
                ]
            }
            for requirement in policy.required_inputs
        },
        "metadata": {
            "requested_by": "REPLACE-ME",
            "product": "REPLACE-ME",
            "jira_key": "REPLACE-ME",
        },
    }
