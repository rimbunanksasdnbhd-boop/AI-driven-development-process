from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .intake import validate_intake
from .models import ValidationResult
from .policies import load_intake_policies


@dataclass(frozen=True)
class Orchestrator:
    policy_path: Path

    def check(self, workflow: str, request: dict[str, Any]) -> ValidationResult:
        policies = load_intake_policies(self.policy_path)
        if workflow not in policies:
            supported = ", ".join(sorted(policies))
            raise ValueError(f"Unknown workflow '{workflow}'. Supported workflows: {supported}")
        return validate_intake(policies[workflow], request)

    @staticmethod
    def load_request(path: str | Path) -> dict[str, Any]:
        request_path = Path(path)
        with request_path.open("r", encoding="utf-8") as handle:
            request = yaml.safe_load(handle) or {}
        if not isinstance(request, dict):
            raise ValueError("request manifest root must be an object")
        return request
