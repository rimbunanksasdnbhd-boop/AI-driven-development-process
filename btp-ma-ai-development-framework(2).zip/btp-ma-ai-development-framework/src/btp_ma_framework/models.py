from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class DecisionStatus(StrEnum):
    BLOCKED = "blocked"
    READY = "ready"


@dataclass(frozen=True)
class InputRequirement:
    key: str
    label: str
    why: str
    accepted_references: tuple[str, ...]
    minimum_references: int = 1
    waiver_allowed: bool = False
    waiver_approval_role: str | None = None


@dataclass(frozen=True)
class WorkflowPolicy:
    name: str
    agent: str
    skill: str
    required_inputs: tuple[InputRequirement, ...]


@dataclass(frozen=True)
class ValidationIssue:
    key: str
    label: str
    reason: str
    accepted_references: tuple[str, ...]
    waiver_allowed: bool
    waiver_approval_role: str | None


@dataclass
class ValidationResult:
    workflow: str
    status: DecisionStatus
    agent: str
    skill: str
    issues: list[ValidationIssue] = field(default_factory=list)
    accepted_waivers: list[str] = field(default_factory=list)

    @property
    def ready(self) -> bool:
        return self.status is DecisionStatus.READY

    def as_dict(self) -> dict[str, Any]:
        return {
            "workflow": self.workflow,
            "status": self.status.value,
            "agent": self.agent,
            "skill": self.skill,
            "issues": [
                {
                    "key": issue.key,
                    "label": issue.label,
                    "reason": issue.reason,
                    "accepted_references": list(issue.accepted_references),
                    "waiver_allowed": issue.waiver_allowed,
                    "waiver_approval_role": issue.waiver_approval_role,
                }
                for issue in self.issues
            ],
            "accepted_waivers": self.accepted_waivers,
        }
