from __future__ import annotations

from typing import Any

from .models import DecisionStatus, ValidationIssue, ValidationResult, WorkflowPolicy


class RequestError(ValueError):
    """Raised when a request manifest has an invalid structure."""


def _references(record: Any) -> list[dict[str, Any]]:
    if not isinstance(record, dict):
        return []
    references = record.get("references", [])
    if not isinstance(references, list):
        return []
    return [item for item in references if isinstance(item, dict) and item.get("value")]


def _valid_waiver(record: Any, policy: WorkflowPolicy, key: str) -> bool:
    if not isinstance(record, dict):
        return False
    requirement = next(item for item in policy.required_inputs if item.key == key)
    if not requirement.waiver_allowed:
        return False
    waiver = record.get("waiver")
    if not isinstance(waiver, dict):
        return False
    return bool(waiver.get("reason") and waiver.get("approved_by") and waiver.get("approved_at"))


def validate_intake(
    workflow_policy: WorkflowPolicy,
    request: dict[str, Any],
) -> ValidationResult:
    inputs = request.get("inputs", {})
    if not isinstance(inputs, dict):
        raise RequestError("request 'inputs' must be an object")

    issues: list[ValidationIssue] = []
    accepted_waivers: list[str] = []

    for requirement in workflow_policy.required_inputs:
        record = inputs.get(requirement.key, {})
        reference_count = len(_references(record))
        if reference_count >= requirement.minimum_references:
            continue
        if _valid_waiver(record, workflow_policy, requirement.key):
            accepted_waivers.append(requirement.key)
            continue
        issues.append(
            ValidationIssue(
                key=requirement.key,
                label=requirement.label,
                reason=requirement.why,
                accepted_references=requirement.accepted_references,
                waiver_allowed=requirement.waiver_allowed,
                waiver_approval_role=requirement.waiver_approval_role,
            )
        )

    status = DecisionStatus.READY if not issues else DecisionStatus.BLOCKED
    return ValidationResult(
        workflow=workflow_policy.name,
        status=status,
        agent=workflow_policy.agent,
        skill=workflow_policy.skill,
        issues=issues,
        accepted_waivers=accepted_waivers,
    )
