from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

import yaml

from .orchestrator import Orchestrator
from .policies import PolicyError, load_intake_policies
from .prompting import render_missing_input_prompt
from .templates import request_template


def _default_policy() -> Path:
    return Path("config/intake-policy.yaml")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="btp-ma")
    parser.add_argument("--policy", type=Path, default=_default_policy())
    subparsers = parser.add_subparsers(dest="command", required=True)

    check = subparsers.add_parser("check", help="Validate a workflow intake request")
    check.add_argument("--workflow", required=True)
    check.add_argument("--request", required=True, type=Path)
    check.add_argument("--json", action="store_true", dest="as_json")

    template = subparsers.add_parser("template", help="Create a request manifest template")
    template.add_argument("--workflow", required=True)
    template.add_argument("--output", type=Path)

    subparsers.add_parser("validate-policy", help="Validate the intake policy configuration")
    return parser


def _check(args: argparse.Namespace) -> int:
    orchestrator = Orchestrator(policy_path=args.policy)
    request = orchestrator.load_request(args.request)
    result = orchestrator.check(args.workflow, request)
    if args.as_json:
        print(json.dumps(result.as_dict(), indent=2))
    else:
        print(f"STATUS: {result.status.value.upper()}")
        print(f"AGENT: {result.agent}")
        print(f"SKILL: {result.skill}")
        print()
        print(render_missing_input_prompt(result))
    return 0 if result.ready else 2


def _template(args: argparse.Namespace) -> int:
    policies = load_intake_policies(args.policy)
    if args.workflow not in policies:
        raise ValueError(f"Unknown workflow '{args.workflow}'")
    data = request_template(policies[args.workflow])
    rendered = yaml.safe_dump(data, sort_keys=False, allow_unicode=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
        print(f"Wrote {args.output}")
    else:
        print(rendered, end="")
    return 0


def _validate_policy(args: argparse.Namespace) -> int:
    policies = load_intake_policies(args.policy)
    print(f"Validated {len(policies)} workflows from {args.policy}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "check":
            return _check(args)
        if args.command == "template":
            return _template(args)
        if args.command == "validate-policy":
            return _validate_policy(args)
    except (ValueError, OSError, PolicyError, yaml.YAMLError) as exc:
        parser.error(str(exc))
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
