"""BTP@MA AI-driven development framework."""

__version__ = "0.1.0"
