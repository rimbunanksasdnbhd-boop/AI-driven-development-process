---
name: verifying-before-completion
description: Use before claiming a BTP@MA artifact is complete, approved, passing, deployable, merged, released, or ready for the next workflow stage.
---
# Verifying Before Completion

## Rule

No completion claim without fresh, directly relevant evidence.

## Gate

1. Identify the evidence that proves the claim.
2. Run or inspect the complete current verification.
3. Read the result, exit status, failure count, and limitations.
4. Check requirement and approval evidence in addition to technical tests.
5. State the actual status with evidence. Do not use confidence as a substitute.

## Examples

- Requirement complete → every required section, source, open decision, and approval is checked.
- Test package complete → every acceptance criterion is covered or explicitly exempted.
- Code complete → clean diff review plus full configured build/tests and relevant contract/smoke checks.
- Release ready → approvals, quality deployment, smoke test, rollback plan, and release evidence exist.

An agent report, an old test run, a partial test command, or a successful linter alone is not sufficient.
