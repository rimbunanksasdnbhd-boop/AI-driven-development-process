---
name: implementing-approved-changes
description: Use when approved BTP@MA requirements and solution design are ready for implementation in an accessible existing repository or codebase.
---
# Implementing Approved Changes

## Entry gate

Do not write code until the intake gate confirms the approved requirement, approved design, codebase, build command, test command, and applicable standards.

## Method

1. Read repository instructions, relevant code, tests, dependencies, and recent changes.
2. Run the configured build and tests to establish the baseline. Record existing failures.
3. Create an isolated branch or worktree named with the Jira/request key.
4. Produce a file-specific implementation plan with small, independently reviewable tasks.
5. Use test-first development for executable business logic. For configuration, generated artifacts, schemas, or deployment descriptors, use the most direct failing validation or contract check.
6. Implement only approved scope and follow existing patterns.
7. Commit small changes with requirement/task references.
8. Run specification-compliance review, then code-quality/security review.
9. Run fresh full build, tests, and relevant smoke/contract checks.
10. Create a pull-request draft with traceability and evidence. Do not merge or deploy without approval.

Never replace missing repository access with guessed code.
