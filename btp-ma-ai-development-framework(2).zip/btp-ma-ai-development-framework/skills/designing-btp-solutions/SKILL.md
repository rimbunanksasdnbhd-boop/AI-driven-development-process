---
name: designing-btp-solutions
description: Use when an approved BTP@MA requirement must be mapped to an implementable SAP BTP architecture or an existing application and integration landscape.
---
# Designing BTP Solutions

## Required design sections

- requirement and source references;
- existing-state summary from repository and architecture evidence;
- affected components and ownership;
- component boundaries and interfaces;
- request, event, and data flows;
- API/event contracts and compatibility;
- data model, validation, persistence, and migration;
- authentication, authorization, privacy, and secret handling;
- error handling, retries, idempotency, and user messages;
- logging, metrics, tracing, and support diagnostics;
- test strategy and environment dependencies;
- deployment, configuration, transport, rollback, and feature controls;
- risks, trade-offs, and architecture decisions;
- `REQ/AC → DES` traceability.

## Rules

Inspect existing patterns before proposing changes. Keep changes focused. Present two or three approaches only where meaningful. Trigger security approval for sensitive changes. Obtain solution approval before implementation planning.
