---
name: using-btp-ma-ai-development
description: Use when a request involves BTP@MA requirement analysis, solution design, test creation, coding, review, deployment, or a change spanning these stages.
---
# Using BTP@MA AI-Driven Development

## Core principle

Ground every stage in the required source material and approval evidence before specialist work begins.

## Workflow

1. Classify the requested outcome into requirement analysis, solution design, test-script creation, coding, or ordered stages.
2. Invoke `collecting-required-inputs` for the current stage.
3. Inspect supplied files, links, Jira references, and repositories before asking questions.
4. When mandatory input is missing, stop and request it. Do not generate a substitute silently.
5. Route ready work to the registered specialist agent and its primary skill.
6. Maintain identifiers across requirement, acceptance criteria, design, tasks, tests, and code.
7. Apply the approvals in `config/approval-gates.yaml`.
8. Apply the permissions in `config/tool-policy.yaml`.
9. Independently review deliverables.
10. Invoke `verifying-before-completion` before any success, merge, release, or Jira-completion claim.

## Non-negotiable boundaries

- Do not start coding without the actual coding base or Git repository.
- Do not create final test scripts without the target template unless an allowed waiver is approved.
- Do not analyze requirements without product documentation unless an allowed waiver is approved.
- Do not expose credentials to prompts or commit them to Git.
- Do not publish, merge, delete, or deploy beyond the user's authorization.
