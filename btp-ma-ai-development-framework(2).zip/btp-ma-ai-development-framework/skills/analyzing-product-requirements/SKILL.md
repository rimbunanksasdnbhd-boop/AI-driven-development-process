---
name: analyzing-product-requirements
description: Use when converting grounded business input and product documentation into an approved BTP@MA requirement, user story, acceptance criteria, and traceability record.
---
# Analyzing Product Requirements

## Output

Create one combined, developer-usable requirement artifact with:

- purpose and business value;
- current behavior and target behavior;
- scope by product, process, country, channel, and user role;
- explicit business rules using numbered `REQ-*` identifiers;
- acceptance criteria using `AC-*` identifiers and Given/When/Then or logic/result format;
- inputs, normalization, validation, persistence, output, and error behavior;
- dependencies, assumptions, exclusions, migration, and rollout;
- affected interfaces/data and non-functional constraints;
- open decisions that genuinely block approval;
- source references and a traceability matrix.

## Method

1. Read all supplied documentation and related stories.
2. Compare requested behavior with documented behavior and existing implementation evidence.
3. Identify contradictions and missing decisions.
4. Ask only unresolved, material questions.
5. Prefer one recommended requirement interpretation; show alternatives only for real business choices.
6. Make each rule deterministic enough that a developer and tester reach the same conclusion.
7. Run a product-definition self-review for ambiguity, unsupported assumptions, and untestable wording.
8. Obtain requirement approval before solution design or coding.

Do not prescribe implementation unless it is an explicit constraint.
