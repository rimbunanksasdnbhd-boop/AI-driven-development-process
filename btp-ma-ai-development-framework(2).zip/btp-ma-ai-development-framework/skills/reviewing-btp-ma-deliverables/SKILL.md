---
name: reviewing-btp-ma-deliverables
description: Use when independently reviewing a BTP@MA requirement, solution design, test package, implementation task, pull request, or release artifact.
---
# Reviewing BTP@MA Deliverables

## Review order

1. **Source grounding:** Are statements supported by the supplied documentation, requirement, design, repository, or evidence?
2. **Specification compliance:** Does the artifact implement exactly the approved scope and all applicable rules?
3. **Traceability:** Are requirement, acceptance-criteria, design, task, test, and code links complete?
4. **Quality:** Is the artifact clear, maintainable, secure, testable, and consistent with existing patterns?
5. **Verification:** Is fresh evidence sufficient for each claim?

## Finding format

Record severity (`blocker`, `major`, `minor`, `suggestion`), affected identifier/file, evidence, impact, and required correction. Block progress for unresolved blockers and majors. Reviewers must not rely only on the creator's summary.
