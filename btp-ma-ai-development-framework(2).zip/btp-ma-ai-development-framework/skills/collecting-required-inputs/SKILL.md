---
name: collecting-required-inputs
description: Use before BTP@MA requirement analysis, solution design, test creation, or coding when source documents, templates, repositories, approvals, or verification commands may be missing.
---
# Collecting Required Inputs

## Core principle

Inspect first, ask only for missing material, and block work that cannot be grounded safely.

## Procedure

1. Identify the current workflow stage.
2. Load `config/intake-policy.yaml`.
3. Inventory everything already supplied in the conversation, request manifest, Jira item, uploaded files, documentation links, and repository.
4. Validate each mandatory input. A title or filename is not proof of accessible content.
5. Request all missing inputs in one concise stage-specific checklist.
6. Accept a waiver only when policy allows it and the record contains a reason, approver, and approval time.
7. Record source type, stable reference, version/commit, and relevant section.
8. Continue only when the intake result is ready.

## Required prompts

### Requirement analysis

Ask for the requirement input, product/process documentation, and related requirement examples.

### Test-script creation

Ask for the approved requirement and acceptance criteria, product documentation, target test-script template, and existing regression examples.

### Coding

Ask for the approved requirement, approved solution design, Git repository or uploaded codebase, base branch, build command, test command, coding standards, and relevant product/API documentation.

## Rules

- Never ask for something already available and readable.
- Never invent product behavior, template fields, repository structure, or test commands.
- A URL that cannot be accessed remains missing; report the access limitation.
- When a user says a source does not exist, apply the configured waiver process rather than pretending it exists.
