---
name: creating-test-scripts
description: Use when approved BTP@MA requirements must be converted into Jira, Xray, Zephyr, manual, API, integration, or regression test cases using a supplied template.
---
# Creating Test Scripts

## Core principle

Follow the supplied test template and prove acceptance-criteria coverage.

## Method

1. Read the approved requirement, all acceptance criteria, product documentation, template, and existing examples.
2. Extract testable rules and build an `AC → test condition` coverage map.
3. Reuse the template's exact fields, naming, step style, priority, component, and data conventions.
4. Create focused cases for relevant positive, negative, boundary, formatting, authorization, integration, persistence, error, locale, concurrency, and regression behavior.
5. State deterministic preconditions, test data, actions, and expected results.
6. Avoid duplicate cases; parameterize only when the target tool supports it clearly.
7. Identify unsupported, ambiguous, or untestable acceptance criteria instead of inventing behavior.
8. Run an independent completeness review and obtain test approval before publication.

## Traceability

Every case must reference at least one `AC-*`. Every `AC-*` must map to one or more cases, or be recorded as intentionally not testable with an approved reason.
