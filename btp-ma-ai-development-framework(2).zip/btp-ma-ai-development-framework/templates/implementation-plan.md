# [JIRA-KEY] Implementation Plan

## Goal

## Approved inputs

## Architecture and constraints

## Baseline commands and result

## File map

| File | Create/modify | Responsibility | Related REQ/AC/DES |
|---|---|---|---|

## Tasks

### TASK-01 — [Independent deliverable]

- Files:
- Interfaces consumed/produced:
- Requirement/design links:
- Failing test or validation:
- Minimal implementation:
- Verification command and expected evidence:
- Commit message:

## Full verification

## Pull-request evidence checklist
