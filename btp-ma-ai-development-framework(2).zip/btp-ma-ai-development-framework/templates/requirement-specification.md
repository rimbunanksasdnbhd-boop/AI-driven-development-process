# [JIRA-KEY] Requirement Specification

## Purpose and business value

## Current behavior

## Target behavior

## Scope

### Included products/processes/countries/roles

### Exclusions

## Business rules

| ID | Rule | Source |
|---|---|---|
| REQ-01 |  |  |

## Acceptance criteria

| ID | Given / input | When / logic | Then / expected result |
|---|---|---|---|
| AC-01 |  |  |  |

## Data, interface, authorization, and error impact

## Dependencies and rollout

## Risks, assumptions, and open decisions

## Traceability

| Requirement | Acceptance criteria | Design | Test cases | Code |
|---|---|---|---|---|
| REQ-01 | AC-01 |  |  |  |

## Source references
