# [TEST-ID] [Test title]

- Requirement/Jira:
- Acceptance criteria:
- Product/component:
- Test type:
- Priority:
- Preconditions:
- Test data:

| Step | Action | Expected result |
|---:|---|---|
| 1 |  |  |

## Postconditions / cleanup

## Automation candidate and notes
