# Security and compliance baseline

- Default-deny tool access.
- No API token or password in prompts, source files, example manifests, logs, or committed `.env` files.
- Resolve credentials inside connector/runtime boundaries.
- Use least-privilege service identities and delegated user identity where required.
- Separate read, draft, publish, merge, deploy, and destructive permissions.
- Require explicit approval for Jira publication, pull-request merge, destination changes, and production deployment.
- Record all write actions and approval evidence.
- Apply data classification and masking before sending content to a model.
- Do not send production personal or confidential data to an unapproved model/provider.
- Validate repository URLs and source paths against allowlists.
- Use protected branches, required reviews, CI checks, secret scanning, and signed release provenance where available.
