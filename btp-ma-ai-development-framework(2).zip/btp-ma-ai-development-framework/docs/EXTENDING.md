# Extending the framework

## Add a workflow

1. Add a workflow and required inputs to `config/intake-policy.yaml`.
2. Register its agent and skill in `config/agent-registry.yaml`.
3. Add approval and tool policies.
4. Create a skill under `skills/<name>/SKILL.md`.
5. Add request examples and tests for blocked, waived, and ready intake.
6. Add traceability and output templates.

## Add a connector

Implement the protocols in `src/btp_ma_framework/connectors/base.py`. Keep credentials outside model context, enforce allowlists and approvals, and return audit metadata.

## Test a skill

Treat skill behavior as process code:

1. Write pressure scenarios that demonstrate failure without the skill.
2. Capture the agent's shortcuts or rationalizations.
3. Write the minimal skill rules that close those gaps.
4. Re-run scenarios with the skill.
5. Add adversarial cases for missing documents, inaccessible URLs, absent repositories, and requests to bypass approval.

## Production hardening backlog

- persistent workflow-state store;
- signed skill registry with version approval;
- real Jira, documentation, GitHub, and BTP connectors;
- policy-as-code enforcement at the connector gateway;
- structured audit events and dashboards;
- model routing and data-masking policy;
- evaluation datasets for each specialist agent;
- CI runner sandboxing and software-supply-chain controls;
- transport and rollback integration.
