# End-to-end workflow

## Stage 1 — Requirement analysis

1. Receive business input.
2. Ask for product documentation and related story examples when not already supplied.
3. Analyze existing behavior and requested change.
4. Produce requirement specification, acceptance criteria, and initial traceability.
5. Obtain Product Owner approval.

## Stage 2 — Solution design

1. Ask for the approved requirement, architecture baseline, and code/repository access.
2. Inspect existing architecture and integration patterns.
3. Produce solution design and architecture decisions.
4. Obtain technical and triggered security approvals.

## Stage 3 — Test design

1. Ask for approved requirements, product documentation, test template, and examples.
2. Create acceptance-criteria coverage map and test cases.
3. Independently review completeness.
4. Obtain quality approval before publishing tests.

Test design can begin after requirement approval and should be refined after solution approval.

## Stage 4 — Coding

1. Ask for the approved requirement/design, actual codebase, branch, commands, and standards.
2. Establish baseline build/tests.
3. Create isolated worktree/branch and implementation plan.
4. Implement task by task with appropriate failing tests or validations.
5. Conduct specification review and code-quality review.
6. Run fresh full verification.
7. Create a pull-request draft and wait for approval.

## Stage 5 — Quality and release

1. Execute automated/manual tests in the controlled environment.
2. Record defects and requirement impact.
3. Verify quality deployment and smoke tests.
4. Obtain release approvals.
5. Deploy using the approved transport path.
6. Verify production health and retain rollback evidence.
