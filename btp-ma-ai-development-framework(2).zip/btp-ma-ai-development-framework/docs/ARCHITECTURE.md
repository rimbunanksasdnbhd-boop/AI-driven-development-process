# Architecture

## Design goals

- Ground agent work in authoritative source material.
- Keep specialist roles stable while allowing reusable skills.
- Prevent unapproved writes and production actions.
- Make every output traceable and independently verifiable.
- Remain model- and harness-neutral.

## Logical components

### Orchestrator

Classifies work, executes intake checks, routes to fixed agents, applies approvals and tool policy, and maintains workflow state.

### Intake gate

Uses `config/intake-policy.yaml`. The Python implementation returns either `ready` or `blocked`, including a user-facing request for missing source material.

### Specialist agents

- Product Definition Agent
- Solution Agent
- Development Agent
- Quality Agent

### Skills Hub

Skills contain judgment-heavy, reusable process instructions. Mechanical controls belong in policy, schemas, CI, and connector code.

### Connectors

Adapters isolate Jira, documentation, GitHub, SAP BTP, CI/CD, and transport tools from model prompts. They must apply authorization, secret resolution, auditing, and approval checks.

### Evidence and traceability

Each run should record request ID, agent, skill version, source references, approvals, outputs, tool actions, verification commands/results, and links across `REQ → AC → DES → TASK → TEST → CODE`.

## Recommended production deployment

Package the orchestrator as a BTP application or internal service. Use an enterprise identity provider, role collections, destination/secret services, audit logging, a database for workflow state, and a queue for controlled long-running execution. Keep development execution in isolated CI runners rather than in the orchestrator process.

The included Python package is a reference control plane, not a production autonomous coding runtime.
