# Installation and GitHub setup

## Create the repository

```bash
git init
git add .
git commit -m "feat: initialize BTP@MA AI development framework"
git branch -M main
git remote add origin <YOUR-GITHUB-REPOSITORY-URL>
git push -u origin main
```

## Branch protection recommendation

Require pull requests, at least one Code Owner approval, successful `Framework CI`, resolved conversations, and no direct pushes to `main`.

## Cursor

Keep `.cursor/rules/btp-ma-ai-development.mdc` enabled. Install Superpowers separately when its planning/worktree/TDD skills are desired.

## Codex and other coding agents

Use `AGENTS.md` as the repository-level instruction entry point. Agent-specific plugin packaging can later point to the same `skills/` directory.

## Enterprise GitHub

Replace example invalid URLs and addresses. Configure GitHub App or approved service-account authentication in the connector runtime, not in this repository.
