## Change summary

## Requirement and design links

- Jira/request:
- REQ/AC identifiers:
- Approved solution design:

## Source material used

- Product documentation:
- Test template/examples:
- Repository baseline:

## Verification evidence

- Baseline build/tests:
- New/changed tests:
- Full build/tests:
- Contract/smoke checks:

## Reviews and approvals

- Specification compliance:
- Code quality/security:
- Required approval gates:

## Risk and rollback
